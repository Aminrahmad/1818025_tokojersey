-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 22, 2021 at 06:37 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jersey_bola`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_jersey`
--

CREATE TABLE `tb_jersey` (
  `id_jersey` varchar(100) NOT NULL,
  `nama_jersey` varchar(100) NOT NULL,
  `ukuran` varchar(100) NOT NULL,
  `harga` int(100) NOT NULL,
  `stok` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_jersey`
--

INSERT INTO `tb_jersey` (`id_jersey`, `nama_jersey`, `ukuran`, `harga`, `stok`) VALUES
('AR001', 'Arsenal', 'XL', 150000, 30),
('AR002', 'Arsenal', 'XXL', 200000, 10),
('CH001', 'Chelsea', 'M', 35000, 10),
('EV001', 'Everton', 'L', 40000, 10),
('MC001', 'Manchester City', 'M', 100000, 20),
('MC002', 'Manchester City', 'L', 90000, 15),
('MU001', 'Manchester United', 'XL', 50000, 5);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_jersey`
--
ALTER TABLE `tb_jersey`
  ADD PRIMARY KEY (`id_jersey`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
